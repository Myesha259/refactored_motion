<?php

$host_name= 'localhost ';
$name ='root';
$pass ='';
$db='online_food';

$con= mysql_connect($host_name,$name,$pass) or die ('Database error!');
mysql_select_db( $con,$db);

















?>








