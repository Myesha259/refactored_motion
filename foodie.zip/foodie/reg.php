<?php

?>
<!DOC type -food delivery >
<html>
<head>
<link rel= "stylesheet" href= "reg.css"></link>

<title> registration</title>
<h2 class="h" align ="center" > registration page for manager</h2>
</head>


<body id ="b">

<div id="d">

<form action =reg.php" method ="post" align ="center">
<center>
<img src ="reg.png" class ="img" ></img></center>
<b>
<label> User-Name </label>
<input name="name" type ="name" id ="form" placeholder ="Enter your name" required></input>
<br>
<b>
<label> User-Email </label>
<input name= "email" type ="email" id ="form" placeholder ="Enter your email" required></input>
<br>
<b>

<label>User-Password </label>
<input name="name" type ="password" id ="form" placeholder ="Enter your password" required></input>
<br>

<b>
<label> confirm_password </label>
<input name="cpass" type ="password" id ="form" placeholder ="confirm your password" required></input> 
<br>
<b>
<label> User-id </label>
<input name="id" type ="id" id ="form" placeholder ="Enter your id" required></input>


<br>
<b>
<label> User-Blood group </label>
<input name="group" type ="radio-button" id ="radio-button" placeholder ="Enter your bg" required></input>
<br>
<b>
<label> Phone_Number </label>
<input name="number" type ="number" id ="form" placeholder ="Enter your phone_no" required></input>
<br>
<b>
<input name="reg" type ="submit" id ="button" value ="Sign-Up" ></input>
<b>

<a href="login.php"><input name="back" type ="button" id ="button" value ="Back to Log-in" ></input>
</form>





</div>



</body>
</html>
