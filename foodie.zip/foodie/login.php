<?php


?>
<! Doc type!-login page>
<html>
<head>
<link rel="stylesheet" href ="login.css"></link>
<title>Log-in </title>
<h2 class="h" align="center"> login </h2>
</head>
<body id ="b">
<div id="d">

 </div>
<form action="login.php" method="POST" align="center">
<center>
<img src="food bur.jpg" class="img"></img></center>
<b>
<label>User-Name</label>
<input name="name" type="text" id="form" placeholder="enter your name"required></input>
<br>
<b>

<label>User-Email</label>
<input name="email" type="email" id="form" placeholder="enter your Email"required></input>
<br>
<b>
<label>User-Password</label>
<input name="pass" type="password" id="form" placeholder="enter your Password"required></input>

<br><br>
<input name="log-in" type="submit" id="button" value= "Log-in"></input>
<b>

<a href="reg.php"> <input name="reg" type="submit" id="button" value="registration"></input>
<b>
</form>
</body>


</html>