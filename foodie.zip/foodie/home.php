<?php



?>
<! Doc type!- restaurant login page>
<html>
<head>
<link rel="stylesheet" href ="foodie.css"></link>
<title>Log-in </title>
<h2 class="h" align="center"> Welcome to Home</h2>
</head>
<body id ="b">
<div id="d">

 </div>
<form action="home.php" method="POST" align="center">
<center>
<img src="home.png" class="img"></img></center>
<b>
<br><br>

 <input name="logout" type="submit" id="button" value="Log-Out"> </input>

</form>
</body>


</html>